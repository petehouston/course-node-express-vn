1) Extract this package into a new directory on your PC. For example: E:\project-movie-api

2) Open Terminal or Command Prompt to this new directory. 

C:\>E:
E:\>cd project-movie-api

3) Install dependencies of project

E:\project-movie\api>npm install

4) To start project, type:

E:\project-movie\api>node index.js

